const config = {
    token: "", // https://discord.com/developers/applications
    color: "00ccff",
    ["mongo database link"]: "",
    ["main guild id"]: "",
    ["status message"]: "Need help? DM me!",
    ["help embed welcome"]: "Welcome to Mod Mail! Here is some commands to help you around."
};

module.exports = config;