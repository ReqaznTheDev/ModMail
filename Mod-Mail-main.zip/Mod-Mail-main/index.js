const fs = require("fs")
require("./src/Client").init()